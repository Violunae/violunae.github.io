#include <iostream>
#include <fstream>
#include <cmath>
#include <climits>
#include <cstdlib>
#include <string>

using namespace std;

int numPlaces(int n) {
    if (n < 0) return numPlaces((n == INT_MIN) ? INT_MAX : -n);
    if (n < 10) return 1;
    return 1 + numPlaces(n / 10);
}

int getNthDigit(int number, int n) {
    int digit = abs(number) / static_cast<int>(pow(10, n - 1)) % 10;
    return digit;
}

void fixpath(std::string& path) {
#ifdef _WIN32
    for (char& ch : path) {
        if (ch == '/') ch = '\\';
    }
#endif
}

void copyFile(const std::string& sourceFile, const std::string& destFile) {
    std::ifstream src(sourceFile, std::ios::binary);
    if (!src.is_open()) {
        std::cout << "Error opening source file " << sourceFile << std::endl;
        return;
    }

    std::ofstream dest(destFile, std::ios::binary);
    if (!dest.is_open()) {
        std::cout << "Error opening destination file " << destFile << std::endl;
        return;
    }

    dest << src.rdbuf();

    std::cout << "File copied successfully from " << sourceFile << " to " << destFile << std::endl;
}
