#ifndef MINESWEEPER_H
#define MINESWEEPER_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <fstream>

typedef enum { CLOSED, OPEN, FLAG } CellState;
typedef enum { INGAME, WIN, LOOSE, EXIT } FieldState;

typedef struct {
    char symbol;
    bool isMine;
    CellState state;
} Cell;

typedef struct {
    Cell** grid;
    int width;
    int height;
    int mines;
    bool firstMove;
    FieldState state;
    unsigned int seed;
    std::ifstream readRecord;
    std::ofstream writeRecord;
    long score;
    bool isRecord;
} Field;

typedef struct CellNode {
    int x;
    int y;
    Cell* cell;
    struct CellNode* next;
} CellNode;

CellNode* addCellNode(CellNode* list, Cell* cell, int x, int y);
Field* createField(int width, int height, int mines, unsigned int seed);
Field* createFieldFromRecord(std::istream& record);

void printField(Field* field);
void freeField(Field* field);
Cell* getCell(Field* field, int x, int y);
int countMines(Field* field, int x, int y);
void populateField(Field* field, int x, int y);
void renderField(Field* field);
int countClosedCells(Field* field);
void checkWin(Field* field);
void openCellLoop(Field* field, CellNode* listToOpen);
bool openCell(Field* field, int x, int y);
bool toggleFlagOnCell(Field* field, int x, int y);

bool openCellCommand(Field* field, const std::string& action, bool isRecord);
bool toggleFlagCommand(Field* field, const std::string& action, bool isRecord);
bool leaveGameCommand(Field* field, const std::string& action, bool isRecord);
void runUserCommand(Field* field, std::string& action, bool isRecord);

void minesweeperLoop(Field* field);

#endif