#ifndef UTILS_H
#define UTILS_H

#include <string>

int numPlaces(int n);
int getNthDigit(int number, int n);
void fixpath(std::string& path);
void copyFile(const std::string& sourceFile, const std::string& destFile);

#endif