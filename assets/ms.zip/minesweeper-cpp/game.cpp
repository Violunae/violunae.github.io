#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <limits>

#include "utils.hpp"
#include "leaderboard.hpp"
#include "minesweeper.hpp"

using namespace std;

void handleGame(Field* field) {
    if (field != nullptr) {
        minesweeperLoop(field);
        long score = field->score;
        bool isRecord = field->isRecord;
        freeField(field);

        cout << "Provide a name for the record (Leave empty to not save): ";
        string recordName;
        getline(cin, recordName);
        if (!recordName.empty()) {
            string destPath = "saves/records/" + recordName + ".msrec";
            string sourcePath = "saves/records/latest.msrec";
            fixpath(destPath);  
            fixpath(sourcePath);
            copyFile(sourcePath, destPath);
            cout << "Record saved!\n";
        }

        if (!isRecord) {
            cout << "Write your name for leaderboard (15 symbols max) (Leave empty to not add): ";
            string leaderName;
            getline(cin, leaderName);
            if (!leaderName.empty()) {
                if (leaderName.size() > 15)
                    leaderName = leaderName.substr(0, 15);
                leaderboardAddScore(leaderName.c_str(), score);
            }
        }
        else {
            cout << "Score can not be added to the leaderboard because the game started from a record.\n";
        }
    }
}

void playGame() {
    Field* field = nullptr;

    while (true) {
        unsigned int seed = time(nullptr);

        cout << "\nChoose difficulty:\n[E] Easy\n[M] Medium\n[H] Hard\n[C] Custom\n[B] Back\n";
        string input;
        getline(cin, input);

        if (input.empty()) continue;
        char command = input[0];
        bool success = false;

        switch (command) {
            case 'e': case 'E':
                field = createField(9, 9, 10, seed);
                success = true;
                break;
            case 'm': case 'M':
                field = createField(16, 16, 40, seed);
                success = true;
                break;
            case 'h': case 'H':
                field = createField(30, 16, 99, seed);
                success = true;
                break;
            case 'c': case 'C': {
                int rows, cols, numMines;
                cout << "Enter the number of rows, columns, and mines: ";
                if (!(cin >> rows >> cols >> numMines) || rows <= 0 || cols <= 0 || numMines <= 0 || numMines >= rows * cols) {
                    cout << "Invalid input!\n";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                    break;
                }
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                field = createField(rows, cols, numMines, seed);
                success = true;
                break;
            }
            case 'b': case 'B':
                success = true;
                break;
        }

        if (success)
            break;
        else
            cout << "Invalid action!\n";
    }

    handleGame(field);
}

void playRecord() {
    std::cout << "Enter the name of the record file: ";
    std::string name;
    std::getline(std::cin, name);

    std::string path = "saves/records/" + name + ".msrec";

    std::ifstream record(path);
    if (!record.is_open()) {
        std::cout << "Invalid record file!\n";
        return;
    }

    Field* field = createFieldFromRecord(record);

    field->readRecord = std::move(record);

    if (field->readRecord.is_open()) {
        std::string _;
        std::getline(field->readRecord, _);
    }

    handleGame(field);
}

void gameLoop() {
    bool close = false;
    while (!close) {
        cout << "\nWelcome to Minesweeper!\nWhat would you like to do?\n[P] Play\n[R] Play record\n[X] Exit\n";
        string input;
        getline(cin, input);

        if (input.empty()) continue;
        char command = input[0];

        switch (command) {
            case 'p': case 'P':
                playGame();
                break;
            case 'r': case 'R':
                playRecord();
                break;
            case 'x': case 'X':
                cout << "Goodbye!\n";
                close = true;
                break;
            default:
                cout << "Invalid action!\n";
                break;
        }
    }
}
