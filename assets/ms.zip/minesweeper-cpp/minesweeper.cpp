#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <cstdlib>
#include <ctime>

#include "utils.hpp"
#include "game.hpp"
#include "minesweeper.hpp"

using namespace std;

CellNode* addCellNode(CellNode* list, Cell* cell, int x, int y) {
    for (CellNode* node = list; node != nullptr; node = node->next) {
        if (node->cell == cell) {
            return list;
        }
    }
    auto* newCellNode = new CellNode;
    newCellNode->x = x;
    newCellNode->y = y;
    newCellNode->cell = cell;
    newCellNode->next = list;
    return newCellNode;
}

#include <fstream>
#include <string>
#include <iostream>

Field* createField(int width, int height, int mines, unsigned int seed) {
    auto* field = new Field;
    field->width = width;
    field->height = height;
    field->mines = mines;
    field->firstMove = true;
    field->state = INGAME;
    field->score = 0;
    field->seed = seed;
    field->isRecord = false;

    field->readRecord = std::ifstream(); 

    std::string path = "saves/records/latest.msrec";
    fixpath(path);

    field->writeRecord.open(path, std::ios::out);
    if (!field->writeRecord.is_open()) {
        std::cerr << "Error: Could not open record file for writing: " << path << std::endl;
    }

    field->grid = new Cell*[height];
    for (int i = 0; i < height; ++i) {
        field->grid[i] = new Cell[width];
        for (int j = 0; j < width; ++j) {
            field->grid[i][j].state = CLOSED;
            field->grid[i][j].isMine = false;
            field->grid[i][j].symbol = '.';
        }
    }

    if (field->writeRecord.is_open()) {
        field->writeRecord << width << " " << height << " " << mines << "\n";
        field->writeRecord << field->seed << "\n";
    }

    return field;
}


Field* createFieldFromRecord(std::istream& record) {
    int width, height, mines;
    unsigned int seed;

    record >> width >> height >> mines;
    record >> seed;

    Field* field = createField(width, height, mines, seed);
    
    field->readRecord = std::ifstream();
    field->isRecord = true;

    return field;
}


void printField(Field* field) {
    int widthDigits = numPlaces(field->width - 1);
    int heightDigits = numPlaces(field->height - 1);

    for (int i = widthDigits; i > 0; --i) {
        printf("%*s", heightDigits + 3, "");
        for (int j = 0; j < field->width; ++j) {
            printf("%d ", getNthDigit(j, i));
        }
        cout << "\n";
    }
    cout << "\n";

    for (int i = 0; i < field->height; ++i) {
        printf("%0*d   ", heightDigits, i);
        for (int j = 0; j < field->width; ++j) {
            Cell& cell = field->grid[i][j];
            if (cell.state == CLOSED) cout << "# ";
            else if (cell.state == FLAG) cout << "F ";
            else printf("%c ", cell.symbol);
        }
        cout << "\n";
    }
    cout << "\n";
}

void freeField(Field* field) {
    for (int i = 0; i < field->height; ++i)
        delete[] field->grid[i];
    delete[] field->grid;

    if (field->readRecord.is_open()) field->readRecord.close();
    if (field->writeRecord.is_open()) field->writeRecord.close();
    delete field;
}


Cell* getCell(Field* field, int x, int y) {
    if (x < 0 || x >= field->width || y < 0 || y >= field->height)
        return nullptr;
    return &field->grid[y][x];
}

int countMines(Field* field, int x, int y) {
    int mines = 0;
    for (int i = y - 1; i <= y + 1; ++i) {
        for (int j = x - 1; j <= x + 1; ++j) {
            Cell* cell = getCell(field, j, i);
            if (cell && cell->isMine) ++mines;
        }
    }
    return mines;
}

void populateField(Field* field, int x, int y) {
    srand(field->seed);
    int minesPlaced = 0;
    while (minesPlaced < field->mines) {
        int i = rand() % field->height;
        int j = rand() % field->width;

        if (field->grid[i][j].isMine || (i >= y - 1 && i <= y + 1 && j >= x - 1 && j <= x + 1))
            continue;

        field->grid[i][j].isMine = true;
        ++minesPlaced;
    }
}

void renderField(Field* field) {
    for (int i = 0; i < field->height; ++i) {
        for (int j = 0; j < field->width; ++j) {
            if (field->grid[i][j].isMine)
                field->grid[i][j].symbol = '*';
            else {
                int mines = countMines(field, j, i);
                field->grid[i][j].symbol = (mines == 0) ? '.' : char('0' + mines);
            }
        }
    }
}

int countCellsWithState(Field* field, CellState state) {
    int count = 0;
    for (int i = 0; i < field->height; ++i)
        for (int j = 0; j < field->width; ++j)
            if (field->grid[i][j].state == state)
                ++count;
    return count;
}

void checkWin(Field* field) {
    int closedCells = (field->width * field->height) - countCellsWithState(field, OPEN);
    if (closedCells <= field->mines)
        field->state = WIN;
}

void givePoints(Field* field) {
    int scoreMult = (100 * field->mines) / (field->width * field->height);
    field->score += scoreMult;
}

void openCellLoop(Field* field, CellNode* listToOpen) {
    CellNode* current = listToOpen;
    CellNode* nextList = nullptr;

    while (current) {
        Cell* cell = current->cell;
        int x = current->x;
        int y = current->y;

        field->grid[y][x].state = OPEN;
        givePoints(field);

        if (countMines(field, x, y) == 0) {
            for (int i = y - 1; i <= y + 1; ++i) {
                for (int j = x - 1; j <= x + 1; ++j) {
                    Cell* neighbor = getCell(field, j, i);
                    if (neighbor && neighbor->state == CLOSED) {
                        neighbor->state = OPEN;
                        givePoints(field);
                        nextList = addCellNode(nextList, neighbor, j, i);
                    }
                }
            }
        }

        CellNode* next = current->next;
        delete current;
        current = next;
    }

    if (nextList)
        openCellLoop(field, nextList);
}

bool openCell(Field* field, int x, int y) {
    Cell* cell = getCell(field, x, y);
    if (!cell) return false;

    if (cell->state == OPEN) {
        bool res = false;
        for (int i = y - 1; i <= y + 1; ++i)
            for (int j = x - 1; j <= x + 1; ++j)
                if (!(i == y && j == x))
                    if (Cell* neighbor = getCell(field, j, i))
                        if (neighbor->state == CLOSED)
                            res |= openCell(field, j, i);
        return res;
    }

    if (field->firstMove) {
        populateField(field, x, y);
        renderField(field);
        field->firstMove = false;
    }

    if (cell->isMine) {
        cell->state = OPEN;
        field->state = LOOSE;
        return true;
    }

    auto* listToOpen = new CellNode{x, y, cell, nullptr};
    openCellLoop(field, listToOpen);
    return true;
}

bool toggleFlagOnCell(Field* field, int x, int y) {
    Cell* cell = getCell(field, x, y);
    if (!cell || cell->state == OPEN)
        return false;
    cell->state = (cell->state == FLAG) ? CLOSED : FLAG;
    return true;
}

bool openCellCommand(Field* field, const std::string& action, bool isRecord) {
    std::istringstream iss(action);
    char cmd;
    int x, y;
    if (iss >> cmd >> x >> y) {
        bool success = openCell(field, x, y);
        if (success) checkWin(field);
        return success;
    }
    return false;
}

bool toggleFlagCommand(Field* field, const std::string& action, bool) {
    std::istringstream iss(action);
    char cmd;
    int x, y;
    if (iss >> cmd >> x >> y)
        return toggleFlagOnCell(field, x, y);
    return false;
}

bool leaveGameCommand(Field* field, const std::string& action, bool isRecord) {
    if (isRecord) {
        std::cout << "Player exited the game\n";
        return false;
    }
    field->state = EXIT;
    return true;
}

void runUserCommand(Field* field, std::string& action, bool isRecord) {
    if (action.empty()) return;

    char command = action[0];
    bool success = false;

    switch (command) {
        case 'o': case 'O':
            success = openCellCommand(field, action, isRecord);
            break;
        case 'f': case 'F':
            success = toggleFlagCommand(field, action, isRecord);
            break;
        case 'x': case 'X':
            success = leaveGameCommand(field, action, isRecord);
            break;
    }

    if (!success && !isRecord)
        std::cout << "Invalid command!\n";
    else if (field->writeRecord.is_open())
        field->writeRecord << action << "\n";
}

void minesweeperLoop(Field* field) {
    while (field->state == INGAME) {
        printField(field);

        std::string action;
        bool isRecord = false;

        if (field->readRecord.is_open()) {
            if (std::getline(field->readRecord, action)) {
                std::cout << "Enter command (recorded): " << action << "\n";
                isRecord = true;
            }
        }

        if (!isRecord) {
            std::cout << "Enter command: ";
            std::getline(std::cin, action);
        }

        runUserCommand(field, action, isRecord);
        std::cout << "\n";
    }

    printField(field);
    std::cout << "Game over! You "
              << ((field->state == EXIT) ? "left" :
                  (field->state == WIN) ? "won" : "lost")
              << " the game!\n";
    std::cout << "Your score: " << field->score << "\n";
}
