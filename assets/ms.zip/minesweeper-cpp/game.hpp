#ifndef GAME_H
#define GAME_H

#include "minesweeper.hpp"

void handleGame(Field* field);
void gameLoop();
void playRecord();
void playGame();

#endif