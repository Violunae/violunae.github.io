#include <iostream>
#include <ctime>

#include "game.hpp"

int main() {
    gameLoop();
    return 0;
}
