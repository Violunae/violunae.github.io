#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

#include "leaderboard.hpp"

using namespace std;

void leaderboardPrint(int top_n) {
    ifstream file(LEADERBOARD_FILE);
    if (!file.is_open()) {
        cout << "Error: Could not open leaderboard file." << endl;
        return;
    }

    vector<LeaderboardEntry> entries;
    LeaderboardEntry entry;

    while (file >> entry.name >> entry.score) {
        entries.push_back(entry);
    }
    file.close();

    sort(entries.begin(), entries.end(),
         [](const LeaderboardEntry &a, const LeaderboardEntry &b) {
             return a.score > b.score;
         });

    cout << "Leaderboard:" << endl;
    int limit = (top_n == -1 || top_n > static_cast<int>(entries.size())) ? entries.size() : top_n;
    for (int i = 0; i < limit; ++i) {
        cout << entries[i].name << ": " << entries[i].score << endl;
    }
}

void leaderboardAddScore(const char *name, long score) {
    ofstream file(LEADERBOARD_FILE, ios::app);
    if (!file.is_open()) {
        cout << "Error: Could not open leaderboard file." << endl;
        return;
    }

    file << name << " " << score << endl;
    file.close();
}
